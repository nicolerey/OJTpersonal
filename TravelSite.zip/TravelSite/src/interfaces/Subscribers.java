/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author zeek
 */
public interface Subscribers {
    public void update(String msg);
    public void display();
}
